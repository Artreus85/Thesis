export const CAR_BRANDS = [
  "Audi",
  "BMW",
  "Chevrolet",
  "Ford",
  "Honda",
  "Hyundai",
  "Kia",
  "Lexus",
  "Mazda",
  "Mercedes-Benz",
  "Nissan",
  "Subaru",
  "Tesla",
  "Toyota",
  "Volkswagen",
  "Volvo",
]

export const FUEL_TYPES = ["Petrol", "Diesel", "Hybrid", "Electric", "LPG", "CNG"]

export const GEARBOX_TYPES = ["Manual", "Automatic", "Semi-automatic", "CVT"]

export const CONDITIONS = ["New", "Used", "Certified Pre-Owned"]

export const BODY_TYPES = [
  "Sedan",
  "SUV",
  "Hatchback",
  "Coupe",
  "Convertible",
  "Wagon",
  "Van",
  "Minivan",
  "Pickup",
  "Truck",
]

export const DRIVE_TYPES = ["FWD", "RWD", "AWD", "4WD"]

export const COLORS = [
  "Black",
  "White",
  "Silver",
  "Gray",
  "Red",
  "Blue",
  "Green",
  "Yellow",
  "Brown",
  "Orange",
  "Purple",
  "Gold",
  "Beige",
]
